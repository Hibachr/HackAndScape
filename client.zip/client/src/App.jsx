import './App.css'
import Header from './components/Header.jsx'
import RegForm from './components/RegForm.jsx'
import About from './components/About.jsx'
import Sponsors from './components/Sponsors.jsx'
import Contact from './components/ContactUs.jsx'
function App() {
  
  return (
    <>
      <div>
      <Header />
      <main>
        <RegForm />
        <About />
        <Sponsors />
        <Contact/>
      </main>
 
      </div>
    </>
  )
}

export default App
