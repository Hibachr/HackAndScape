import React from "react";
 import spo from "../assets/Group 10.png";
;
const Sponsors = () => {
    return (   <section id="sponsors" className="sponsors-section">
        
  <img src={spo} alt="404" />

    </section>); 
  };
  export default Sponsors